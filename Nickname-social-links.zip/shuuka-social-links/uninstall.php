<?php
delete_option('shuuka_user_page_setting');
